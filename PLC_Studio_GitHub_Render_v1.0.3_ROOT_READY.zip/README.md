# PLC/Collaborative Team Studio — GitHub / Render MCP package

This repository package contains the Python MCP backend for PLC/Collaborative Team Studio. It is separate from the OpenAI public-listing ZIP.

## Files
- `server.py` — Streamable HTTP MCP server and six PLC Studio tools.
- `requirements.txt` — Python dependencies.
- `render.yaml` — Render web-service blueprint with persistent disk.
- `.env.example` — local environment-variable template; contains no secrets.
- `DEPLOYMENT-CHECKLIST.md` — GitHub → Render → OpenAI verification workflow.
- `SECURITY-AND-PUBLIC-REVIEW.md` — important production-authentication boundary.

## Tool contract
The server preserves these six tool names:
1. `get_meeting_protocol`
2. `list_studio_meetings`
3. `load_studio_meeting`
4. `create_studio_meeting`
5. `save_studio_progress`
6. `get_studio_record`

`save_studio_progress` uses `expected_version` optimistic locking so stale writes fail rather than silently overwrite newer meeting work.

## Local run
Use Python 3.12+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
DATA_DIR=./data python server.py
```

MCP endpoint: `http://localhost:8000/mcp`
Health endpoint: `http://localhost:8000/health`

Use MCP Inspector to initialize the server, list tools, and exercise representative calls. Opening `/mcp` in a normal browser is not a protocol test.

## Render
Create a private GitHub repository, upload these files at the repository root, and deploy using `render.yaml` or a Python Web Service. The service listens on `0.0.0.0:$PORT`. A persistent disk is configured at `/var/data` so SQLite records survive restarts.

After deployment, the MCP endpoint is:

`https://YOUR-RENDER-SERVICE.onrender.com/mcp`

## OpenAI domain verification
When the plugin portal gives you the challenge token, add it in Render as the secret environment variable `OPENAI_DOMAIN_VERIFICATION_TOKEN`, redeploy, and verify that the exact token is returned as plain text at:

`https://YOUR-RENDER-SERVICE.onrender.com/.well-known/openai-apps-challenge`

Never commit the token to GitHub.

## Important production boundary
This source package intentionally makes the persistence/authentication issue visible rather than hiding it. The included SQLite implementation is suitable for owner-controlled development and protocol testing. **Do not use the saved-meeting tools as a public multi-user service until user authentication and per-user authorization are implemented.** See `SECURITY-AND-PUBLIC-REVIEW.md`.
