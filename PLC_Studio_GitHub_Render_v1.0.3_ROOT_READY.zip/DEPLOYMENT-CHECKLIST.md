# Deployment checklist

## GitHub
- [ ] Create a private repository for PLC/Collaborative Team Studio.
- [ ] Upload the contents of this package to the repository root.
- [ ] Confirm `.env`, SQLite databases, tokens, and credentials are not committed.
- [ ] Commit to `main`.

## Render
- [ ] Create/deploy the service from the GitHub repository.
- [ ] Runtime: Python.
- [ ] Branch: `main`.
- [ ] Build: `pip install -r requirements.txt`.
- [ ] Start: `python server.py`.
- [ ] Confirm the persistent disk is mounted at `/var/data`.
- [ ] Confirm `/health` returns status `ok`.
- [ ] Copy the production `/mcp` HTTPS URL.

## MCP verification
- [ ] Connect MCP Inspector to the production `/mcp` endpoint.
- [ ] Confirm all six tools appear.
- [ ] Confirm read-only tools have readOnlyHint=true, destructiveHint=false, openWorldHint=false.
- [ ] Confirm create/save tools have readOnlyHint=false, destructiveHint=false, openWorldHint=false.
- [ ] Create a draft meeting using a UUID.
- [ ] Save progress with the current `expected_version`.
- [ ] Attempt a stale-version save and confirm it fails.
- [ ] Load the meeting and retrieve the Studio record.

## OpenAI portal
- [ ] Use the public-listing ZIP, not this GitHub ZIP, for the plugin package upload.
- [ ] Point its `mcp.json` to the final production `/mcp` endpoint.
- [ ] Add the exact portal challenge token to Render as `OPENAI_DOMAIN_VERIFICATION_TOKEN`.
- [ ] Verify `/.well-known/openai-apps-challenge` returns only the exact token.
- [ ] Complete authentication before public use of private saved meeting records.
- [ ] Connect/reconnect the MCP server.
- [ ] Run Scan Tools and resolve every actionable finding.
- [ ] Re-run the acceptance/evaluation prompts.
- [ ] Complete listing, demo video, release notes, five positive cases, and three negative cases.
