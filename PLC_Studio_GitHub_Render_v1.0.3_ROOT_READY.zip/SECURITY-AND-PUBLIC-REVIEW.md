# Security and public-review boundary

PLC Studio stores meeting notes, decisions, actions, and continuity records. Those records are user-related private data. A public multi-user MCP server therefore needs real user authentication and authorization; a shared API key, an untrusted user-id header, or a model-supplied facilitator identifier is not an adequate substitute.

The repository implementation uses SQLite and is deliberately suitable only for owner-controlled development/testing until an authenticated identity layer is connected. Before public listing, the production service must scope `list_studio_meetings`, `load_studio_meeting`, `create_studio_meeting`, `save_studio_progress`, and `get_studio_record` to the authenticated facilitator. OpenAI's current MCP guidance expects OAuth 2.1 for user-specific private data and write actions.

Do not log access tokens or unnecessary meeting content. Do not return internal account IDs, trace IDs, or credentials in tool results. Keep domain-verification tokens and any future OAuth credentials in Render secret environment variables, never in GitHub.

The public privacy policy should accurately disclose that PLC Studio can store facilitator-created meeting records, the purpose of that storage, retention/deletion behavior, and any service providers involved.
